 <?php
    session_start();
    /*

    */
    if(isset($_POST['btnUpdate'])){
        #code....
    }
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
        Log in page
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<div class="container">
    </br>
    </br>
    <h3 class="h3">
        Learn IT Easy Online Shop 
        <button type="button" class="btn btn-primary" style="float: right;"><i class="fa fa-shopping-cart"></i>
          Cart <span class="badge badge-light"><?php echo $_SESSION['product_quantity'] ?></span>
        </button>
    </h3> 
    <hr>
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col"> </th>
                            <th scope="col">Product</th>
                            <th scope="col">Size</th>
                            <th scope="col" class="text-center">Quantity</th>
                            <th scope="col" class="text-right">Price</th>
                            <th scope="col" class="text-right">Total</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <?php if(isset($_SESSION['my_cart'])) { ?>
                        <?php $Totalprice=0 ?>
                        <?php foreach ($_SESSION['my_cart'] as $index => $product) { /*lage munalamu rinig item mo*/ ?>
                            <tbody>
                                <tr>
                                    <td><?php /* echo $product['img'] */ ?></td>
                                    <td><?php /* echo $product['name'] */ ?></td>
                                    <td><?php /* echo $product['quantity'] */ ?></td>
                                    <td><?php /* echo $product['price'] */ ?></td>
                                    <td><?php /* echo $Totalprice */ ?><strong>Total</strong></td>
                                    <td class="text-right"><strong>346,90 €</strong></td>
                                </tr>
                            </tbody>
                        <?php } ?>
                    <?php } ?>
                </table>
            </div>
        </div>
        <div class="col mb-2">
            <div class="row">
                <div class="col-sm-12  col-md-6">
                    <a href="" class="btn btn-block btn-light">Continue Shopping</a>
                </div>
                <div class="col-sm-12 col-md-6 text-right">
                    <button class="btn btn-lg btn-block btn-success text-uppercase" name="">Update</button>
                </div>
                <div class="col-sm-12  col-md-6">
                    <a href="" class="btn btn-lg btn-block btn-success text-uppercase">Continue Shopping</a>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>