<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
        Log in page
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>



<div class="container">
    </br>
    </br>
    <h3 class="h3">
        Learn IT Easy Online Shop 
        <button type="button" class="btn btn-primary" style="float: right;"><i class="fa fa-shopping-cart"></i>
          Cart <span class="badge badge-light"><?php echo $_SESSION['product_quantity'] ?></span>
        </button>
    </h3> 
    <hr>
    <div class="row">
        <div class="col-md-10 col-sm-6">
         <h3>Product Successfully Added to the Cart, What do you want to do next?</h3>
         <button type="submit" class="btn btn-primary mb-2" name="purchace">View Cart</button>
         <button type="button" class="btn btn-danger mb-2" onclick="location.href='index.php';">Continue Shopping</button>
     </div>
    </div>
</div>
<hr>
<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>