<?php
session_start();
  if(isset($_POST['purchase'])){
    /*
      add me ing item king cart session gamit kang  php func... parang append
      this item mast have the img, price, quantity, size of the product clicked...
      kahit array nemu ing item mo, maka session seman ing cart...
      value in item array
      $_SESSION['array'][$_GET['k']]['name']
      $_SESSION['array'][$_GET['k']]['photo1']
      $_SESSION['array'][$_GET['k']]['price']
      add me ing size pong quan. bat king input
      $_POST['size']
      $_POST['quantity']

      keni nakarin mag add king product_quantity mo...
    */
      /*
        pero bayu me add ing item
        gawa kang costom function na mag validate kung atin yang kapareho
        para eya mag doble item mo...
      */
  }
  /*
  function name(){}
  */
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
        Log in page
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<div class="container">
    </br>
    </br>
    <h3 class="h3">
        Learn IT Easy Online Shop 
        <button type="button" class="btn btn-primary" style="float: right;"><i class="fa fa-shopping-cart"></i>
          Cart <span class="badge badge-light"><?php echo $_SESSION['product_quantity'] ?></span>
        </button>
    </h3> 
    <hr>
    <div class="row">
        <div class="col-md-3 col-sm-6">
             
            <div class="product-grid2">
                <div class="product-image2">
                    <a href="#">
                        <img class="pic-1" src="img/<?php echo  $_SESSION['array'][$_GET['k']]['photo1']; ?>">
                        <img class="pic-2" src="img/<?php echo  $_SESSION['array'][$_GET['k']]['photo2']; ?>">
                    </a>
                </div>
            </div>
        </div>
        <div class="col-md-9 col-sm-6">
            <form action="details.php" method="post">
               <h3><?php echo $_SESSION['array'][$_GET['k']]['name']; ?> <span class="badge badge-dark">₱ <?php echo $_SESSION['array'][$_GET['k']]['price']; ?></span></h3>
               <p><?php echo $_SESSION['array'][$_GET['k']]['description']; ?></p>
                <hr>
                <h3>Select Size</h3>
                <div class="custom-control custom-radio custom-control-inline">
                  <input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input" value="XS">
                  <label class="custom-control-label" for="customRadioInline1">XS</label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                  <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input" value="SM<">
                  <label class="custom-control-label" for="customRadioInline2">SM</label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                  <input type="radio" id="customRadioInline3" name="customRadioInline1" class="custom-control-input" value="MD">
                  <label class="custom-control-label" for="customRadioInline3">MD</label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                  <input type="radio" id="customRadioInline4" name="customRadioInline1" class="custom-control-input" value="LG">
                  <label class="custom-control-label" for="customRadioInline4">LG</label>
                </div>
                <div class="custom-control custom-radio custom-control-inline">
                  <input type="radio" id="customRadioInline5" name="customRadioInline1" class="custom-control-input" value="XL">
                  <label class="custom-control-label" for="customRadioInline5">XL</label>
                </div>
                <hr>
                <h3>Enter Quantity</h3>
                <input class="form-control" type="number" name="quantity">
                <br>
                <button type="submit" class="btn btn-primary mb-2" name="purchase">Confirm Product Purchase</button>
                <button type="button" class="btn btn-danger mb-2" onclick="location.href='index.php';">Cancel Go/Back</button>
            </form>   
        </div>
    </div>
</div>
<hr>
<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
