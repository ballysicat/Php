<?php
	session_start();
	$arrProducts = array(
		array(
			'name'			=> "Brown Shirt",
			'description'	=> "Brown Short-sleeved, crew-neck oversize T-shirt. Made of cotton",
			'price'			=> "550",
			'photo1'		=> "product1A.jpg",
			'photo2'		=> "product1B.jpg",
		),
		array(
			'name'			=> "Gray Shirt",
			'description'	=> "Gray Short-sleeved, crew-neck oversize T-shirt. Made of cotton",
			'price'			=> "550",
			'photo1'		=> "product2A.jpg",
			'photo2'		=> "product2B.jpg",
		),
		array(
			'name'			=> "White Blazer",
			'description'	=> "A standalone jacket worn with trousers of a contrasting color, pattern or material. The jacket is usually made of navy blue serge; hopsack, worsteds or wool flannel are classic alternatives, while fresco or linen are used for warmer weather. Striped blazers are often made of wool flannel or cotton.",
			'price'			=> "750",
			'photo1'		=> "product3A.jpg",
			'photo2'		=> "product3B.jpg",
		),
		array(
			'name'			=> "Dark Blue Polo Shirt",
			'description'	=> "made of knitted cotton (rather than woven cloth), usually a piqué knit, or less commonly an interlock knit (the latter used frequently, though not exclusively, with pima cotton polos), or using other fibers such as silk, merino wool, synthetic fibers, or blends of natural and synthetic fibers.",
			'price'			=> "600",
			'photo1'		=> "product4A.jpg",
			'photo2'		=> "product4B.jpg",
		),
		array(
			'name'			=> "Blue Long Sleeves",
			'description'	=> "Blue Collared and have long sleeves (reaching a point to the wrist to a little beyond wrist)",
			'price'			=> "800",
			'photo1'		=> "product5A.jpg",
			'photo2'		=> "product5B.jpg",
		),
        array(
            'name'          => "White Long Sleeves",
            'description'   => "White Collared have long sleeves (reaching a point to the wrist to a little beyond wrist)",
            'price'         => "800",
            'photo1'        => "product6A.jpg",
            'photo2'        => "product6B.jpg",
        ),
        array(
            'name'          => "Dark Blue Blazer",
            'description'   => "A bomber jacket is traditionally a short (waist-length) outerwear that has a gathered, ribbed waistband and matching cuffs. It has a zipper front and often has four functional pockets at the top and sides. Aside from leather, bombers’ are also made using polyester, nylon and cotton.",
            'price'         => "750",
            'photo1'        => "product7A.jpg",
            'photo2'        => "product7B.jpg",
        ),
        array(
            'name'          => "Floral Polo",
            'description'   => "Huilishi hawaiian bohemian floral printed mens button down polo with pocket slim fit short sleeves.",
            'price'         => "650",
            'photo1'        => "product8A.jpg",
            'photo2'        => "product8B.jpg",
        ),		
		);
    /*  option mo nung buri meng hiwalay ing item count...
        if(!isset($_SESSION['may_cart'])){
            $_SESSION['may_cart'];
            $_SESSION['product_quantity']=0;
        }
    */

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>
        Shopping Cart
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>



<div class="container">
    </br>
    </br>
    <h3 class="h3">
        Learn IT Easy Online Shop 
        <button type="button" class="btn btn-primary" style="float: right;"><i class="fa fa-shopping-cart"></i>
          Cart <span class="badge badge-light"><?php echo $_SESSION['product_quantity'] ?></span>
        </button>
    </h3> 
    <hr>
    <div class="row">
         <?php foreach($arrProducts as $products => $product){ 
             $_SESSION['array'][] = array(
                'name'          =>  $product['name'],
                'description'   =>  $product['description'],
                'price'         =>  $product['price'],
                'photo1'        =>  $product['photo1'],
                'photo2'        =>  $product['photo2'],
            );
         ?>
           
        <div class="col-md-3 col-sm-6">
            <div class="product-grid2">
                <div class="product-image2">
                    <a href="details.php?k=<?php echo $products ?>">
                        <img class="pic-1" src="img/<?php echo $product['photo1']; ?>">
                        <img class="pic-2" src="img/<?php echo $product['photo2']; ?>">
                    </a> 
                    <a class="add-to-cart" href="details.php?k=<?php echo $products ?>"><i class="fa fa-shopping-cart"></i> Add to cart</a>
                </div>
                <div class="product-content">
                    <h3 class="title"><?php echo $product['name']; ?> <span class="badge badge-dark">₱ <?php echo $product['price']; ?></span></h3>
                    
                </div>
            </div>
        </div>
    </div>


</div>
<hr>
<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>
